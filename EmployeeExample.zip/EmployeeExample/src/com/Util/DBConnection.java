package com.Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static final String dbDriver = "com.mysql.jdbc.Driver";
	private static final String dbUrl =" jdbc:mysql://localhost:3306/naveen";
	private static final String dbUser = "root";
	private static final String dbPassword = "root";
	public static Connection getDBConnection() 
	{
		Connection dbConnection = null;
		try 
		{
			Class.forName(dbDriver);
		}
		catch (ClassNotFoundException e) 
		{
			System.err.println(e.getMessage());
		}

		try 
		{
			dbConnection = (Connection)DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			return dbConnection;
		}
		catch (SQLException e) 
		{
			System.err.println(e.getMessage());
		}

		return dbConnection;

	}
}