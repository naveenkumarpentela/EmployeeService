package com.employee.junit;

import static org.junit.Assert.assertNotNull;

import java.time.Duration;
import java.time.Instant;

import com.test.Employee;
import com.test.EmployeeServiceImpl;
import com.test.Response;

public class EmployeeTest extends EmployeeServiceImpl {

	
	@Test
	public void createEmployee() throws Exception {
		
		EmployeeServiceImpl impl = new EmployeeServiceImpl();
		Employee e = new Employee();
		e.setEmpDepartment("IT");
		e.setEmployeeID(100);
		e.setEmployeeName("Naveen");
		e.setJoiningDate("2019-25-05 10:55:10");
		Response respo = impl.addEmployee(e);
		
		assertNotNull(respo);
		assertEquals(respo.getMessage(), "Employee got created successfully");

	}
	
	@Test
	public void updateEmployee() throws Exception {
		
		EmployeeServiceImpl impl = new EmployeeServiceImpl();
		Employee e = new Employee();
		e.setEmpDepartment("IT");
		e.setEmployeeID(100);
		e.setEmployeeName("Naveen Kumar");
		e.setJoiningDate("2019-25-05 10:55:10");
		Response respo = impl.updateEmployee(e);
		
		assertNotNull(respo);
		assertEquals(respo.getMessage(), "system doesn't allow update on employee in a 24 hour period");

	}
	
	@Test
	public void serviceTimeLog() throws Exception {
		Instant start = Instant.now();
		EmployeeServiceImpl impl = new EmployeeServiceImpl();
		Employee e = new Employee();
		e.setEmpDepartment("IT");
		e.setEmployeeID(100);
		e.setEmployeeName("Naveen Kumar");
		e.setJoiningDate("2019-25-05 10:55:10");
		Response respo = impl.updateEmployee(e);
		
		Instant end = Instant.now();
		Duration timeElapsed = Duration.between(start, end);
		System.out.println(timeElapsed);
		
		assertNotNull(respo);
		assertEquals(respo.getMessage(), "system doesn't allow update on employee in a 24 hour period");
}
