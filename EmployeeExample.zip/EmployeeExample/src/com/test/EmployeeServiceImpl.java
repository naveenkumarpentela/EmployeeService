package com.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

@Path("/employee")
@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_XML)
public class EmployeeServiceImpl implements EmployeeService {
//	PropertyConfigurator.configure("log4j.properties");
	static Logger log = Logger.getLogger(EmployeeServiceImpl.class.getName());
	private static Map<Integer, Employee> employees = new HashMap<Integer, Employee>();
	Connection con = null;

	@Override
	@POST
	@Path("/add/")
	public Response addEmployee(Employee e) {
		Instant start = Instant.now();
		Response response = new Response();
		int count = 0;
		boolean valid = false;
		try {
			log.info("Connection Establishment Start");
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/naveen", "root", "root");
			log.info("Connection established successfully");
			valid = jaxbObjectToXML(e);
		} catch (Exception e2) {
			e2.printStackTrace();
			log.info("Database connection erroe");
		}

		/*
		 * if(employees.get(e.getEmployeeID()) != null){ response.setStatus(false);
		 * response.setMessage("Person Already Exists"); return response; }
		 */
		if (valid == true) {
			if (e.getEmployeeID() != 0) {
				log.info("Employee id is-->>" + e.getEmployeeID());
				try {
					PreparedStatement stmt = con.prepareStatement("select count(*) from employee where empid=?");
					stmt.setInt(1, e.getEmployeeID());
					java.sql.ResultSet rs = stmt.executeQuery();
					while (rs.next()) {
						count = rs.getInt(1);
					}
					stmt.close();
					if (count == 1) {
						log.info("Employee Already Exists");
						response.setStatus(false);
						response.setMessage("Person Already Exists");
						// return response;
					} else {
						log.info("Employee not found in DB-wait for a moment-saving details in DB in processing");
						java.util.Date date = new java.util.Date();
						java.sql.Date sqlDate = new java.sql.Date(date.getTime());
						String currentDate = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").format(sqlDate);
//					LocalDateTime localDateTime = LocalDateTime.now();
//					 
//					Date date = Date.from( localDateTime.atZone( ZoneId.systemDefault()).toInstant());
						// java.sql.Timestamp sqlTime = new java.sql.Timestamp(date.getTime());
						try {
							PreparedStatement pstmt = con.prepareStatement("insert into employee values(?,?,?,?,?)");
							pstmt.setInt(1, e.getEmployeeID());
							pstmt.setString(2, e.getEmployeeName());
							pstmt.setString(3, e.getEmpDepartment());
							pstmt.setDate(4, new java.sql.Date(
									(new SimpleDateFormat("dd-MM-yyyy").parse(e.getJoiningDate())).getTime()));
							pstmt.setTimestamp(5, new Timestamp(date.getTime()));
							pstmt.execute();
							System.out.println("data inserted successfully");
							log.info("Employee Details saved successfully");
							pstmt.close();
							con.close();
							response.setMessage("Employee got created successfully");
							response.setStatus(true);
							log.info("Response sent back in XML");
							// return response;
						} catch (Exception e1) {
							e1.printStackTrace();
							log.info("Insertion error-please check the values that u passed");
						}
					}
					Instant end = Instant.now();
					Duration timeElapsed = Duration.between(start, end);
					System.out.println(timeElapsed);
					return response;

				} catch (SQLException e1) {
					System.out.println("Invalid Employee Id, must be numeric");
					log.info("OOPS-something wentr wroing with ur code");
				}
			}
			log.info("XML is a vaid input");
			System.out.println("XML is a vaid input");
		} else {
			log.info("XML is not a valid one. Please provide a vaid input");
			System.out.println("XML is not a valid one. Please provide a vaid input");
		}
		return response;
	}

	@GET
	@Path("/{id}/getDummy")
	public Employee getDummyPerson(@PathParam("id") int id) {
		Employee e = new Employee();
		e.setEmployeeID(99);
		e.setEmployeeName("Naveen Kumar P");
		e.setEmpDepartment("IT");
		e.setJoiningDate(String.valueOf(new java.util.Date()));
		return e;
	}

	@Override
	@PUT
	@Path("/update")
	public Response updateEmployee(Employee e) {
		Instant start = Instant.now();
		Response response = new Response();
		Timestamp ts = null;
		boolean valid = false;
		try {
			if (valid) {
				valid = jaxbObjectToXML(e);
				String lastCrawlDate = "2014-01-28";
				Date utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(lastCrawlDate);
				java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/naveen", "root", "root");

				PreparedStatement stmtlogDateRetrieval = con.prepareStatement("select * from employee where empid=?");
				stmtlogDateRetrieval.setInt(1, e.getEmployeeID());
				java.sql.ResultSet rs = stmtlogDateRetrieval.executeQuery();
				while (rs.next()) {
					ts = rs.getTimestamp(5);
					Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
					// logic to calculate the time difference
					long milliseconds = currentTimeStamp.getTime() - ts.getTime();
					int seconds = (int) milliseconds / 1000;
					// calculate hours minutes and seconds
					int hours = seconds / 3600;
					int minutes = (seconds % 3600) / 60;
					seconds = (seconds % 3600) % 60;
					log.info(hours + "h:" + minutes + "m:" + "00s");
					// if time difference is less than 24 hrs send status and add Restricted status
					// in table
					if (hours < 24) {
						response.setMessage("system doesn't allow update on employee in a 24 hour period");
						response.setStatus(false);
						return response;
						// if time difference is greater than 24 hrs else part will be executed
					} else {
						Statement stmt = con.createStatement();
						if (e.getEmployeeID() != 0) {
							String query = "update employee set empName = '" + e.getEmployeeName() + "',department='"
									+ e.getEmpDepartment() + "',joining_date='" + sqlDate + "' where empid = '"
									+ e.getEmployeeID() + "'";
							int k = stmt.executeUpdate(query);
							if (k == 1) {
								response.setMessage("Updated Employee details");
								response.setStatus(true);
								System.out.println("Employee details update done");
								log.info("Employee details update done");
							} else {
								response.setMessage("Updated Employee details is not done");
								response.setStatus(false);
							}
						} else {
							log.info("Pass a valid Employee ID");
						}
						return response;
					}
				}
				log.info("XML is a valid one");
			} else {
				log.info("XML is not a valid one");
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		Instant end = Instant.now();
		Duration timeElapsed = Duration.between(start, end);
		log.info(timeElapsed);
		return response;
	}

	private boolean validate(String xmlFile, String schemaFile) {
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		try {
			log.info("Validation started");
			Schema schema = schemaFactory.newSchema(new File(getResource(schemaFile)));

			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(new File(getResource(xmlFile))));
			log.info("Validation Ended");
			return true;
		} catch (SAXException | IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	private String getResource(String filename) throws FileNotFoundException {
		URL resource = getClass().getClassLoader().getResource(filename);
		Objects.requireNonNull(resource);

		return resource.getFile();
	}

	private boolean jaxbObjectToXML(Employee employee) {
		boolean valid = false;
		try {
			log.info("Object to XML conversion Started");
			// Create JAXB Context
			JAXBContext jaxbContext = JAXBContext.newInstance(Employee.class);

			// Create Marshaller
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// Required formatting??
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

			// Print XML String to Console
			StringWriter sw = new StringWriter();

			// Write XML to StringWriter
			jaxbMarshaller.marshal(employee, sw);

			// Verify XML Content
			String xmlContent = sw.toString();
			System.out.println("xmlContent is --> " + xmlContent);

			valid = validate(xmlContent, "E:\\Naveen\\Workspace\\EmployeeExample\\WebContent\\WEB-INF\\employee.xsd");
			log.info("Object to XML conversion ended");
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return valid;
	}
}